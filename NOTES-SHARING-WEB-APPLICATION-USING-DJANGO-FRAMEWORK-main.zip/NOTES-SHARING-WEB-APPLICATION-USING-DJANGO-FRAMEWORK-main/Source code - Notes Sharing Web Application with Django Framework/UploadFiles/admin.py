from django.contrib import admin
from .models import MyFileUpload

# Register your models here.

admin.site.register(MyFileUpload)